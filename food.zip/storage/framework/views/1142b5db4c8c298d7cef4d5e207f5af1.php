
<?php $__env->startSection('title'); ?>
    Home~Page
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="px-5 mb-5 mt-3">
        <form action="<?php echo e(route('storePage')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <label for="photo" class="text-capitalize">Enter your food item photo</label><br>
            <input value="<?php echo e(old('photo')); ?>" type="file" name="photo" class="form-control form-control-lg"><br>

            <label for="name" class="text-capitalize">Enter your food item name</label><br>
            <input value="<?php echo e(old('name')); ?>" type="text" name="name" class="form-control form-control-lg">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-warning"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>

            <label for="item">Select your item category: </label><br>
            <select name="item">
                <option value="" disabled selected class="text-secondary">Choose Your Item</option>
                <option value="Fruit and vegetables">Fruit and vegetables</option>
                <option value="Starchy food">Starchy food</option>
                <option value="Dairy">Dairy</option>
                <option value="Protein">Protein</option>
                <option value="Fat">Fat</option>
            </select>
            <?php $__errorArgs = ['item'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-warning"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br><br>

            <label for="title" class="text-capitalize">Enter your food item title name</label><br>
            <input value="<?php echo e(old('title')); ?>" type="text" name="title" class="form-control form-control-lg">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-warning"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>


            <label for="componentDescription">Enter your food item components description</label><br>
            <textarea name="componentDescription" cols="30" rows="5" class="form-control form-control-lg"><?php echo e(old('componentDescription')); ?></textarea>
            <?php $__errorArgs = ['componentDescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-warning"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>

            <label for="positiveDescription">Enter your food item short description</label><br>
            <textarea name="positiveDescription" cols="30" rows="5" class="form-control form-control-lg"><?php echo e(old('positiveDescription')); ?></textarea>
            <?php $__errorArgs = ['positiveDescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-warning"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>

            <label for="negativeDescription">Enter your food item short description</label><br>
            <textarea name="negativeDescription" cols="30" rows="5" class="form-control form-control-lg"><?php echo e(old('negativeDescription')); ?></textarea>
            <?php $__errorArgs = ['negativeDescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-warning"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>

            <input type="submit" class="btn btn-primary" value="Submit">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\1. Laravel 11 Folder\food\resources\views/admin/index.blade.php ENDPATH**/ ?>