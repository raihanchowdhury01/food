
<?php $__env->startSection('title'); ?>
    Protein food category review || This review help to you for choose the healthy protein food item
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($items->isNotEmpty()): ?>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->Category === 'Protein'): ?>
            <div class="w-75 mx-auto">
                <div class="mt-5 w-50 mx-auto">
                    <img class="smd_width" style="border-radius: 100%" src="<?php echo e(url('Uploaded_Photo/'. $item->Image)); ?>" alt="This is a pizza">
                    <p class="text-center w-75 text-capitalize ps-5"><?php echo e($item->Name); ?></p>
                </div>
                <div>
                    
                    <div>
                        <h1><?php echo e($item->Title); ?></h1>
                    </div>
                    
                    <div>
                        <?php if(strlen($item->positiveDescription) > 500 || strlen($item->positiveDescription) < 500): ?>
                            <p><?php echo e(substr($item->positiveDescription, 0, 500)); ?>...</p>
                        <?php else: ?>
                            <p><?php echo e($item->positiveDescription); ?></p>
                        <?php endif; ?>
                        <a href="<?php echo e(url('view', $item->id)); ?>" class="btn btn-primary">See Details</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="mt-5 py-5 text-center">
                <?php echo e($items->links()); ?>

            </div>
            <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\1. Laravel 11 Folder\food\resources\views/users/protein.blade.php ENDPATH**/ ?>