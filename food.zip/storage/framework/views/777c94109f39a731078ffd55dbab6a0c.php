
<?php $__env->startSection('title'); ?>
    View Details Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="w-75 mx-auto">
    <div class="mt-5 w-50 mx-auto">
        <img class="md_width" style="border-radius: 100%" src="<?php echo e(url('Uploaded_Photo/'. $item->Image)); ?>" alt="This is a pizza">
        <p class="text-center text-capitalize name_width"><?php echo e($item->Name); ?></p>
    </div>
    <div>
        
        <div>
            <h1><?php echo e($item->Title); ?></h1>
        </div>
        
        <div class="mt-5">
            <p class="text-capitalize py-3 fs-4">Components of this food:</p>
        </div>
        <div>
            <ul>
                <?php $__currentLoopData = explode('||', $item->componentDescription); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($line); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        
        <div class="mt-5">
            <p class="text-capitalize py-3 fs-4">Positive Side of this food:</p>
        </div>
        <div>
            <p><?php echo e($item->positiveDescription); ?></p>
        </div>

        
        <div class="mt-5">
            <p class="text-capitalize py-3 fs-4">Negative side of this food:</p>
        </div>
        <div>
            <p><?php echo e($item->negativeDescription); ?></p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\1. Laravel 11 Folder\food\resources\views/admin/longView.blade.php ENDPATH**/ ?>