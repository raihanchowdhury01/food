
<?php /**PATH E:\1. Laravel 11 Folder\food\resources\views/components/application-logo.blade.php ENDPATH**/ ?>