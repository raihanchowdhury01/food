<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo e(asset('img/logo.jpg')); ?>" type="image/x-icon">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="<?php echo e(asset('https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css')); ?>" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="<?php echo e(asset('https://kit.fontawesome.com/cc76e3cc3d.js')); ?>" crossorigin="anonymous"></script>
    <style>
      .md_width{
            width: 100%;
        }
      @media (min-width: 769px) {
          .md_width{
            width: 50%;
            margin-left: 25%;
        }
          .smd_width{
            width: 50%;
            margin-left: 20%;
        }
      }
  </style>
  </head>
  <body>
    
    <header>
        <div class="d-flex justify-content-between py-3 px-5 bg-primary text-white align-items-center">
            <div>
                <img style="width: 20%" src="<?php echo e(url('img/logo.jpg')); ?>" alt="there is a logo image">
            </div>
            <div>
              <ul class="d-flex list-unstyled gap-5">
                <li class="nav-item"><a class="nav-link" href="<?php echo e(asset('admin/dashboard')); ?>">View</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(asset('admin/dashboard/input')); ?>">Input</a></li>
              </ul>
                
            </div>
        </div>
    </header>
    

    
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    

    <script src="<?php echo e(asset('https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js')); ?>" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH E:\1. Laravel 11 Folder\food\resources\views/admin/master.blade.php ENDPATH**/ ?>